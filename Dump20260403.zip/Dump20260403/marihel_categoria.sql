-- MySQL dump 10.13  Distrib 8.0.42, for macos15 (x86_64)
--
-- Host: marihel.ck38iw4amrdb.us-east-1.rds.amazonaws.com    Database: marihel
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `categoria`
--

DROP TABLE IF EXISTS `categoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categoria` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_categoria_nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoria`
--

LOCK TABLES `categoria` WRITE;
/*!40000 ALTER TABLE `categoria` DISABLE KEYS */;
INSERT INTO `categoria` VALUES (11,'Anillo Caballero'),(9,'Anillo Diamante'),(8,'Anillo Esmeralda'),(4,'Anillo Mediano'),(5,'Anillo Pesado dama'),(10,'Anillo Piedra Preciosa'),(36,'Anillo semipreciosa'),(2,'Anillos'),(6,'Anillos Compromiso'),(42,'Anillos esmeralda existencia'),(43,'Anillos existencia'),(7,'Anillos Oro Blanco'),(3,'Anillos Rosados'),(17,'Aretes'),(1,'Argollas'),(16,'Aros'),(13,'Cadena Caballero'),(12,'Cadena Dama'),(40,'Cadena existencia'),(14,'Cadena Oro Blanco'),(32,'Cadenas Livianas'),(37,'Cadenas vitrina'),(18,'Candongas'),(19,'Candongas Hoggies'),(27,'Cristos'),(30,'Cuellos'),(33,'Diamantes'),(39,'Dije esmeralda duo'),(41,'Dije existencia'),(45,'Dije juego básico'),(24,'Dijes'),(26,'Dijes Esmeralda'),(25,'Dijes Letra'),(35,'Dimar'),(34,'Esmeraldas'),(28,'Medallas'),(47,'Otros'),(31,'Pulsera hilo'),(15,'Pulseras'),(44,'Pulseras existencia'),(20,'Topos'),(22,'Topos Diamante'),(23,'Topos Doble Servicio'),(21,'Topos Esmeralda'),(38,'Topos esmeralda duo'),(46,'Topos juego básico'),(29,'Vitrina');
/*!40000 ALTER TABLE `categoria` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-03 15:28:08

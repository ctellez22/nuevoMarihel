-- MySQL dump 10.13  Distrib 8.0.42, for macos15 (x86_64)
--
-- Host: marihel.ck38iw4amrdb.us-east-1.rds.amazonaws.com    Database: marihel
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `categoria_verificacion`
--

DROP TABLE IF EXISTS `categoria_verificacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categoria_verificacion` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre_categoria` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ultima_fecha_verificacion` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoria_verificacion`
--

LOCK TABLES `categoria_verificacion` WRITE;
/*!40000 ALTER TABLE `categoria_verificacion` DISABLE KEYS */;
INSERT INTO `categoria_verificacion` VALUES (1,'Argollas','2026-03-20 12:23:22'),(2,'Anillos','2026-03-19 11:26:56'),(3,'Anillos Oro Blanco','2024-03-19 00:00:00'),(4,'Anillos Rosados','2026-03-19 15:49:33'),(5,'Anillo Mediano','2026-03-19 11:44:17'),(6,'Anillo Pesado dama','2026-03-18 16:52:51'),(7,'Anillos Compromiso','2026-03-19 11:01:33'),(8,'Anillos Oro Blanco','2024-03-19 00:00:00'),(9,'Anillo Esmeralda','2026-03-11 17:05:40'),(10,'Anillo Diamante','2026-03-24 14:41:09'),(11,'Anillo Piedra Preciosa','2026-03-26 16:18:14'),(12,'Anillo Caballero','2026-03-18 16:39:04'),(13,'Cadena Dama','2026-03-19 13:26:35'),(14,'Cadena Caballero','2026-03-19 12:07:29'),(15,'Cadena Oro Blanco','2026-03-26 10:29:59'),(16,'Pulseras','2026-03-19 15:29:46'),(17,'Aros','2026-03-24 12:01:35'),(18,'Aretes','2026-03-26 11:43:59'),(19,'Candongas','2026-03-19 16:56:55'),(20,'Candongas Hoggies','2026-03-24 11:06:13'),(21,'Topos','2026-03-25 15:12:41'),(22,'Topos Esmeralda','2026-03-25 12:27:26'),(23,'Topos Diamante','2026-03-25 10:10:48'),(24,'Topos Doble Servicio','2026-03-25 15:55:52'),(25,'Dijes','2026-03-18 13:33:16'),(26,'Dijes Letra','2026-03-18 14:06:59'),(27,'Dijes Esmeralda','2025-09-18 14:12:45'),(28,'Cristos','2026-03-18 14:27:41'),(29,'Medallas','2026-03-18 12:35:36'),(30,'Vitrina','2026-03-25 09:46:13'),(31,'Cuellos','2026-03-25 16:15:51'),(32,'Pulsera hilo','2026-03-26 11:39:33'),(33,'Otros','2025-03-28 16:14:45'),(34,'Diamantes','2026-03-26 11:43:11'),(35,'Anillos Oro Blanco','2025-03-28 16:15:20'),(36,'Cadenas Livianas','2026-03-19 14:18:46'),(37,'Anillos Esmeralda existencia','2025-06-03 16:36:20'),(38,'Cadena existencia','2025-06-06 15:52:29'),(39,'Anillos Oro Blanco','2025-07-28 17:32:24'),(40,'Anillos Oro Blanco','2025-07-28 17:33:04'),(41,'Anillos Oro Blanco','2025-09-18 14:46:36'),(42,'Anillos Oro Blanco','2025-10-23 14:12:10'),(43,'Anillos Oro Blanco','2025-10-25 12:43:29'),(44,'Topos esmeralda duo','2026-03-25 16:05:31'),(45,'Topos juego básico','2026-03-25 16:02:53'),(46,'Dije juego básico','2026-03-25 16:13:55'),(47,'Anillos Oro Blanco','2026-03-18 16:32:44'),(48,'Anillos Oro Blanco','2026-03-18 16:32:49'),(49,'Anillos Diamante','2026-03-27 17:08:15'),(50,'Dije esmeralda duo','2026-03-25 16:09:22'),(51,'Cadenas vitrina','2026-03-26 10:23:09'),(52,'Esmeraldas','2026-03-26 11:43:24');
/*!40000 ALTER TABLE `categoria_verificacion` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-03 15:28:25
